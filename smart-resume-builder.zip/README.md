# 📝 Smart Resume Builder with AI Suggestions

An interactive resume builder that helps you create, preview, and export resumes with **AI-powered improvement suggestions**.

## 🚀 Features
- Interactive Resume Form
- AI Suggestions (via OpenAI API)
- Resume Preview
- Save to MongoDB
- Export Resume as PDF

## 🛠️ Tech Stack
- **Frontend:** React.js, Tailwind CSS
- **Backend:** Node.js, Express.js, MongoDB
- **AI:** OpenAI GPT API
- **PDF Export:** react-to-print / jspdf

## ⚡ Getting Started

### Clone Repo
```bash
git clone https://github.com/your-username/smart-resume-builder.git
```

### Setup Backend
```bash
cd backend
npm install
```
Create a `.env` file:
```
MONGO_URI=your_mongo_connection
OPENAI_API_KEY=your_openai_key
```
Run server:
```bash
npm start
```

### Setup Frontend
```bash
cd frontend
npm install
npm start
```

## 📦 Deployment
- Frontend → Netlify / Vercel
- Backend → Render / Railway
- Database → MongoDB Atlas

## 📜 License
MIT License
