import React from "react";
import ResumeForm from "./components/ResumeForm";
import ResumePreview from "./components/ResumePreview";
import Suggestions from "./components/Suggestions";

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-6 grid grid-cols-2 gap-6">
      <ResumeForm />
      <div>
        <ResumePreview />
        <Suggestions />
      </div>
    </div>
  );
}

export default App;
