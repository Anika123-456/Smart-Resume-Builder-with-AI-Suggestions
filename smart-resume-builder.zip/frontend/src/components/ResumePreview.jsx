import React from "react";

function ResumePreview() {
  return (
    <div className="bg-white p-4 rounded-xl shadow mb-4">
      <h2 className="text-xl font-bold">Live Preview</h2>
      <p className="text-gray-600">Your resume will appear here...</p>
    </div>
  );
}

export default ResumePreview;
