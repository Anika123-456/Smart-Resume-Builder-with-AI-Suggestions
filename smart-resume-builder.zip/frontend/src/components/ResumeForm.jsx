import React, { useState } from "react";

function ResumeForm() {
  const [resume, setResume] = useState({ name: "", email: "", phone: "", education: "", experience: "", skills: "", projects: "" });

  const handleChange = (e) => setResume({ ...resume, [e.target.name]: e.target.value });

  const handleSave = async () => {
    await fetch("http://localhost:5000/api/resume/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(resume),
    });
    alert("Resume Saved!");
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <h2 className="text-xl font-bold mb-3">Resume Builder</h2>
      {Object.keys(resume).map((field) => (
        <input
          key={field}
          name={field}
          value={resume[field]}
          onChange={handleChange}
          placeholder={field}
          className="w-full mb-2 p-2 border rounded"
        />
      ))}
      <button onClick={handleSave} className="bg-blue-500 text-white px-4 py-2 rounded">Save</button>
    </div>
  );
}

export default ResumeForm;
