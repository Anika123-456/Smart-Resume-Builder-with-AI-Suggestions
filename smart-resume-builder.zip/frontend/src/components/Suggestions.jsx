import React, { useState } from "react";

function Suggestions() {
  const [input, setInput] = useState("");
  const [suggestions, setSuggestions] = useState("");

  const getSuggestions = async () => {
    const res = await fetch("http://localhost:5000/api/resume/suggestions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: input }),
    });
    const data = await res.json();
    setSuggestions(data.suggestions);
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <h2 className="text-xl font-bold mb-3">AI Suggestions</h2>
      <textarea
        className="w-full p-2 border rounded mb-2"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Paste resume text here..."
      />
      <button onClick={getSuggestions} className="bg-green-500 text-white px-4 py-2 rounded">
        Get Suggestions
      </button>
      <div className="mt-3 p-2 border rounded bg-gray-50">
        {suggestions || "No suggestions yet..."}
      </div>
    </div>
  );
}

export default Suggestions;
