import express from "express";
import { saveResume, getResume, aiSuggestions } from "../controllers/resumeController.js";

const router = express.Router();

router.post("/save", saveResume);
router.get("/:id", getResume);
router.post("/suggestions", aiSuggestions);

export default router;
