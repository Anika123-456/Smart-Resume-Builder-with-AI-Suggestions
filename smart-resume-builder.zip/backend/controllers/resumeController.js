import Resume from "../models/Resume.js";
import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const saveResume = async (req, res) => {
  try {
    const resume = new Resume(req.body);
    await resume.save();
    res.json({ message: "Resume saved successfully!" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getResume = async (req, res) => {
  try {
    const resume = await Resume.findById(req.params.id);
    res.json(resume);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const aiSuggestions = async (req, res) => {
  try {
    const { content } = req.body;
    const response = await client.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: `Improve this resume:\n${content}` }],
    });

    res.json({ suggestions: response.choices[0].message.content });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
